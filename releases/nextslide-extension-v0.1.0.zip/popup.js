import{r as o,c as S,j as e,B as h,I as j}from"./input-_XO1fvSD.js";/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=(...s)=>s.filter((t,r,n)=>!!t&&t.trim()!==""&&n.indexOf(t)===r).join(" ").trim();/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=s=>s.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,r,n)=>n?n.toUpperCase():r.toLowerCase());/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=s=>{const t=L(s);return t.charAt(0).toUpperCase()+t.slice(1)};/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var v={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=s=>{for(const t in s)if(t.startsWith("aria-")||t==="role"||t==="title")return!0;return!1},M=o.createContext({}),A=()=>o.useContext(M),I=o.forwardRef(({color:s,size:t,strokeWidth:r,absoluteStrokeWidth:n,className:m="",children:l,iconNode:i,...x},a)=>{const{size:d=24,strokeWidth:p=2,absoluteStrokeWidth:g=!1,color:f="currentColor",className:c=""}=A()??{},u=n??g?Number(r??p)*24/Number(t??d):r??p;return o.createElement("svg",{ref:a,...v,width:t??d??v.width,height:t??d??v.height,stroke:s??f,strokeWidth:u,className:N("lucide",c,m),...!l&&!_(x)&&{"aria-hidden":"true"},...x},[...i.map(([w,y])=>o.createElement(w,y)),...Array.isArray(l)?l:[l]])});/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=(s,t)=>{const r=o.forwardRef(({className:n,...m},l)=>o.createElement(I,{ref:l,iconNode:t,className:N(`lucide-${E(C(s))}`,`lucide-${s}`,n),...m}));return r.displayName=C(s),r};/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]],$=b("moon",z);/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],W=b("settings",B);/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],R=b("sun",T),U="https://nextslide.app",k="nextslide_theme";function O(){const[s,t]=o.useState("dark");o.useEffect(()=>{chrome.storage.sync.get([k],n=>{t(n[k]??"dark")})},[]);function r(){const n=s==="dark"?"light":"dark";t(n),chrome.storage.sync.set({[k]:n})}return[s,r]}function P({state:s}){const t=s.code??"",r=(s.participants??[]).filter(a=>a.role==="speaker"),[n,m]=o.useState(!1);function l(){const a=`${U}/s/${t}`;navigator.clipboard.writeText(a).then(()=>{m(!0),setTimeout(()=>m(!1),2e3)})}function i(){const a=chrome.runtime.getURL("manager.html");chrome.tabs.query({url:a},d=>{d.length>0&&d[0].id!==void 0?(chrome.tabs.update(d[0].id,{active:!0}),d[0].windowId!==void 0&&chrome.windows.update(d[0].windowId,{focused:!0})):chrome.tabs.create({url:a})})}function x(){chrome.runtime.sendMessage({type:"disconnect"})}return e.jsxs("div",{className:"flex flex-col gap-3",children:[e.jsxs("div",{className:"flex flex-col items-center gap-1",children:[e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx("span",{className:"inline-block w-2 h-2 rounded-full bg-primary animate-pulse"}),e.jsx("span",{className:"text-[11px] font-semibold tracking-widest uppercase text-primary",children:"Live"})]}),e.jsx("div",{className:"font-mono text-3xl font-bold tracking-[0.2em] text-ns-fg",children:t}),e.jsx(h,{variant:"ghost",size:"sm",onClick:l,className:"mt-0.5 border border-ns-dimmer text-ns-muted text-xs px-3 py-1 h-auto hover:border-ns-fg hover:text-ns-fg",children:n?"Copied!":"Copy link"})]}),e.jsxs("div",{className:"bg-ns-surface border border-ns-border rounded-lg px-3 py-2",children:[e.jsxs("div",{className:"text-[10px] font-semibold uppercase tracking-wider text-ns-faint mb-1.5",children:["Speakers (",r.length,")"]}),r.length===0?e.jsx("div",{className:"text-xs text-ns-dimmer italic",children:"No one yet — share the link!"}):e.jsx("div",{className:"flex flex-col gap-1 max-h-[120px] overflow-y-auto",children:r.map(a=>e.jsxs("div",{className:"flex items-center gap-1.5 text-xs text-ns-fg",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-[#3b82f6] shrink-0"}),a.name]},a.id))})]}),e.jsx(h,{variant:"ghost",size:"sm",onClick:i,className:"w-full border border-ns-dimmer text-ns-muted text-xs hover:border-ns-fg hover:text-ns-fg",children:"Open manager →"}),e.jsx(h,{variant:"ghost",size:"sm",onClick:x,className:"w-full border border-ns-dimmer text-ns-muted text-xs hover:border-red-500 hover:text-red-400",children:"End session"})]})}function Z({initialError:s}){const[t,r]=o.useState(()=>localStorage.getItem("nextslide_presenter_name")??""),[n,m]=o.useState(""),[l,i]=o.useState(""),[x,a]=o.useState(!1),[d,p]=o.useState(s??null);o.useEffect(()=>{chrome.storage.local.get(["lastCode"],c=>{c.lastCode&&!n&&m(c.lastCode)})},[]);function g(){const c=t.trim();c&&localStorage.setItem("nextslide_presenter_name",c),i("Starting…"),a(!1),chrome.runtime.sendMessage({type:"startSession",name:c||void 0},u=>{u!=null&&u.error&&(i(u.error),a(!0))})}function f(){const c=n.trim(),u=t.trim();if(c.length!==6){i("Enter a 6-character code"),a(!0);return}u&&localStorage.setItem("nextslide_presenter_name",u),chrome.storage.local.set({lastCode:c}),chrome.runtime.sendMessage({type:"connect",code:c,name:u||void 0}),i("Connecting…"),a(!1)}return e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx(j,{placeholder:"Your name",maxLength:32,value:t,onChange:c=>r(c.target.value)}),e.jsx(h,{variant:"green",className:"w-full",onClick:g,children:"Start session"}),e.jsxs("div",{className:"flex items-center gap-2 my-1 text-ns-dimmer text-[11px]",children:[e.jsx("span",{className:"flex-1 h-px bg-ns-border"}),"or join with code",e.jsx("span",{className:"flex-1 h-px bg-ns-border"})]}),e.jsxs("div",{className:"flex gap-2 items-stretch",children:[e.jsx(j,{placeholder:"ABC123",maxLength:6,value:n,onChange:c=>m(c.target.value.toUpperCase().replace(/[^A-Z0-9]/g,"")),className:"text-center text-xl tracking-widest uppercase flex-1"}),e.jsx(h,{variant:"outline",onClick:f,className:"shrink-0 px-4",children:"Join"})]}),l&&e.jsx("div",{className:`text-xs mt-0.5 ${x?"text-red-500":"text-ns-subtle"}`,children:l}),d&&e.jsx("div",{className:"text-xs text-red-500",children:d})]})}function q(){const[s,t]=o.useState(null),[r,n]=O();o.useEffect(()=>{chrome.runtime.sendMessage({type:"getState"},i=>{t(i??{connected:!1,code:null,participants:[]})});const l=i=>{t(x=>i.error&&!i.connected&&x&&!x.connected?{...x,error:i.error}:i)};return chrome.runtime.onMessage.addListener(l),()=>chrome.runtime.onMessage.removeListener(l)},[]);function m(){chrome.runtime.openOptionsPage()}return s===null?e.jsx("div",{className:"w-[300px] p-4 bg-ns-bg flex items-center justify-center h-12 text-ns-faint text-xs",children:"Loading..."}):e.jsxs("div",{className:`w-[300px] p-4 bg-ns-bg text-ns-fg ${r==="light"?"ns-light":""}`,children:[e.jsxs("div",{className:"flex items-center justify-between mb-3.5",children:[e.jsx("span",{className:"font-mono text-[11px] font-bold tracking-[0.1em] text-ns-faint uppercase",children:"nextslide.app"}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx("button",{onClick:n,className:"text-ns-subtle hover:text-ns-fg transition-colors p-0.5","aria-label":"Toggle theme",children:r==="dark"?e.jsx(R,{size:13}):e.jsx($,{size:13})}),e.jsx("button",{onClick:m,className:"text-ns-subtle hover:text-ns-fg transition-colors p-0.5","aria-label":"Settings",children:e.jsx(W,{size:13})})]})]}),s.connected&&s.code?e.jsx(P,{state:s}):e.jsx(Z,{initialError:s.error})]})}const J=document.getElementById("root");S(J).render(e.jsx(q,{}));
